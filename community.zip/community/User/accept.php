<?php
	session_start();
	include('config.php');

	if(isset($_POST['from'])) {
		$sql = "INSERT INTO friends (friendsWith, friendOf, friendsSince) VALUES ('".$_SESSION["userID"]."', '".$_POST["from"]."', now())";
		$result = mysqli_query($db, $sql);

		$sql = mysqli_query($db, "UPDATE requests SET status = 'Friends' WHERE requestFrom = '".$_POST["from"]."' AND requestTo = '".$_SESSION["userID"]."'");

		echo ("<script language='javascript'>
                    window.location.href='requests.php';
                </script>");
	}
?>