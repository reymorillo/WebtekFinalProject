<?php
include('config.php');
session_start();


$sql = "SELECT * from users u WHERE u.idno ='".$_SESSION["userID"]."'";

$result = mysqli_query($db, $sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()){
            echo" <form name='editprofile' action='update2.php' method='POST' enctype='multipart/form-data'>
                    <div class='form-group'>
                        <div>
                            <input class='form-control' type='text' name='fName' value='$row[fName]'>
                        </div>
                        <div>
                            <small>First Name</small>
                        </div>
                    </div>
                    <div class='form-group'>
                        <div>
                            <input class='form-control' type='text' name='mName' value='$row[mName]'>
                        </div>
                        <div>
                            <small>Middle Name</small>
                        </div>
                    </div>
                    <div class='form-group'>
                        <div>
                            <input class='form-control' type='text' name='lName' value='$row[lName]'>
                        </div>
                        <div>
                            <small>Last Name</small>
                        </div>
                    </div>
                    <div class='form-group'>
                        <div>
                            <input class='form-control' type='text' name='username' value='$row[username]'>
                        </div>
                        <div>
                            <small>Username</small>
                        </div>
                    </div>
                    <div class='form-group'>
                        <div>
                            <input class='form-control' type='text' name='password' value='$row[password]'>
                        </div>
                        <div>
                            <small>Password</small>
                        </div>
                  
                    </div>
                    <div class='form-group'>
                        <div>
                            <img id='myImg' src='data:image/jpeg;base64,".base64_encode($row["image"])."' height='100px' width='auto' />
                        </div>
                        <div>
                           	<small>Upload Profile Photo:</small>
                            <input name='image' id='image' value='' type='file' multiple accept='image/gif, image/jpeg, image/png'>
        			    </div>
                    </div>
                    <div class='form-group'>
                        <div>
                            <button class='btn btn-default btn-block submit-button' type='Submit' value='Submit' id='submit'>Save Changes</button>
                        </div>
                    </div>
                </form>";
                    
        }
    }
?>