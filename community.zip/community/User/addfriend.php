<?php
	session_start();
	include('config.php');

    if(isset($_POST['idno'])) {
        $sql = "INSERT INTO requests (requestFrom, requestTo, requestDate, status) VALUES ('".$_SESSION["userID"]."','".$_POST["idno"]."',now(),'Pending')";
        $result = mysqli_query($db, $sql);

        echo ("<script language='javascript'>
                    window.location.href='index.php';
                </script>");
        
        if($sql) {
            echo ("<script language='javascript'>
                swal({
                    title: 'Friend Added',
                    text: 'The request was sent.',
                    type: 'success',
                    showCancelButton: true,
                    confirmButtonColor: '#DD6B55',
                    confirmButtonText: 'Try To Add Another',
                    cancelButtonText: 'Go to Main Page',
                    closeOnConfirm: false,
                    closeOnCancel: false
                },
                function(isConfirm){
                    if (isConfirm) {
                        window.location.href='search.php';
                    } else {
                        window.location.href='index.php';
                    }
                });
                </script>");
        } else {
            echo ("<script language='javascript'>
                swal({
                    title: 'Failed',
                    text: 'The request was not sent.',
                    type: 'error',
                    showCancelButton: true,
                    confirmButtonColor: '#DD6B55',
                    confirmButtonText: 'Try To Add Another',
                    cancelButtonText: 'Go to Main Page',
                    closeOnConfirm: false,
                    closeOnCancel: false
                },
                function(isConfirm){
                    if (isConfirm) {
                        window.location.href='search.php';
                    } else {
                        window.location.href='index.php';
                    }
                });
                </script>");
        }
    }
?>