<?php
	session_start();
	include('config.php');

	$searchValue = $_POST['searchValue'];

	$sql = "SELECT u.idno, CONCAT(u.fName, '&nbsp;', u.mName, '&nbsp;', u.lName) AS name, u.gender FROM users u WHERE u.idno != '".$_SESSION["userID"]."' AND u.status = 'Active' AND (u.fName LIKE '%$searchValue%' OR u.mName LIKE '%$searchValue%' OR u.lName LIKE '%$searchValue%') AND u.accountType = 'User' ORDER BY u.lName ASC";
	$result = mysqli_query($db, $sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<header>
		<form method="POST" action="search.php">
			<input name="searchValue" type="search" placeholder="Search for more friends">
			<noscript><input type='submit' value='Submit'></noscript>
		</form>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="requests.php">Requests</a></li>
				<li><a href="messages.php">Messages</a></li>
				<li><a href="profile.php">Profile</a></li> <!--insert php code to fetch user's name (optional)-->
				<li><a href="logout.php">Log out</a></li>
			</ul>
		</nav>
	</header>
	<div class="body">
		<div class="table-responsive">
			<table>
				<tbody>
					<?php
						if($result->num_rows > 0) {
							while($row = mysqli_fetch_array($result)) {
								echo "<tr>";
								echo "<td><h3>".$row['name']."</h3></td>";
								echo "<td><small>".$row['gender']."</small></td>";
								echo "<td>
										<form action='addfriend.php' method='POST' enctype='multipart/form-data'>
		                                    <input name='idno' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='$row[idno]'/>
		                                    <input type='submit' value='+Add as Friend'>
		                                </form>
									</td>";
								echo "<tr>";
							}
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
	<footer>
		<div>
			<p>Copyright &copy; 2017 <a href="">Community</a></p>
		</div>
	</footer>
</body>
</html>