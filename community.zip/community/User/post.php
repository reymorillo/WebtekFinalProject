<?php
	session_start();
	include('config.php');
	if(isset($_POST['textarea'])) {
		$sql = "INSERT INTO posts (idno, post, visibility, postedOn) VALUES ('".$_SESSION["userID"]."','".$_POST["textarea"]."','".$_POST["visibility"]."',now())";
		$result = mysqli_query($db,$sql);

		if($sql) {
			echo ("<script language='javascript'>
						window.location.href='index.php';
					</script>");	
		} else {
			echo "di nag insert";
		}

	}
?>