<?php
	include('login.php');
	if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['accountType'] == 'User') {
		header("Location: User/index.php");
	} else {
		$_SESSION["accountType"] = 'Invalid';
		session_destroy();
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<link rel="stylesheet" type="text/css" href="style/bootstrap/bootstrap.min.css">
	<script src="style/js/jquery.min.js"></script>
	<script src="style/js/bootstrap.min.js"></script>
</head>
    <header> <img src="finallogo.png"></header>
<body>
	<div class="body">
		<div class="login-card">
			<form method="POST">
				<input name="username" type="text" id="username" placeholder="Username" required>
				<input name="password" type="password" id="password" placeholder="Password" required>
				<button type="submit">Log in</button>
			</form>
		</div>
		<p>Don't have an account?</p>
		<!-- Trigger the modal with a button -->
		<a href="#myModal" id="signup" data-toggle="modal">Sign up now!</a>
	</div>
	<div class="modal fade" id="myModal" role="dialog">
	    <div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Sign Up Form</h4>
				</div>
				<div class="modal-body">
					<form method="POST" action="signup.php" enctype="multipart/form-data">
						<div>
							<input type="text" name="idno" placeholder="ID Number" maxlength="7" minlength="7" required>
						</div>
						<div>
							<input type="text" name="firstName" placeholder="First Name" required>
						</div>
						<div>
							<input type="text" name="middleName" placeholder="Middle Name">
						</div>
						<div>
							<input type="text" name="lastName" placeholder="Last Name" required>
						</div>
						<div>
							<input type="number" name="age" min="15" placeholder="Age" required>
						</div>
						<div>
							<input type="Date" name="birthday" required>
						</div>
						<div>
							<select name="gender">
								<option name="option1" value="Male">Male</option>
								<option name="option2" value="Female">Female</option>
							</select>
						</div>
						<div>
							<small>Upload Profile Photo:</small>
	                    	<input name="image" id="image" type="file" multiple accept="image/gif, image/jpeg, image/png">
						</div>
						<div>
							<input type="text" name="username" placeholder="Username" onkeyup="javascript:this.value=this.value.replace(/[<, >]/g,'');" pattern=".{6,}" title="The password should be atleast 6 characters!" required>
						</div>
						<div>
							<input type="password" name="password" placeholder="Password" pattern=".{6,}" title="Password should be atleast 6 characters!" required>
						</div>
						<input name="signup" id="signup" class="btn btn-default submit-button" type="submit" value="Sign Up">
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
	    </div>
	</div>
</body>
</html>