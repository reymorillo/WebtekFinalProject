<?php
	include('config.php');
	session_start();

	if(isset($_POST['idno'])) {
		$idno = $_POST['idno'];
		$sql = "SELECT idno FROM users WHERE idno = '$idno'";
		$result = mysqli_query($db, $sql);
		$count = mysqli_num_rows($result);
		
		if($count == 0) {
			$username = $_POST['username'];
			$password = $_POST['password'];
			$username = stripslashes($username);
			$username = mysqli_real_escape_string($db, $username);
			$password = stripslashes($password);
			$password = mysqli_real_escape_string($db, $password);

			if(isset($_POST['firstName'], $_POST['middleName'], $_POST['lastName'], $_POST['gender'], $username, $password)) {
				if(!empty($_FILES['image']['error'] == 0)) {
					$image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
				} else {
					$image = addslashes(file_get_contents('avatar.jpg'));
				}

				$sql2 = "INSERT INTO users (idno, fName, mName, lName, gender, username, password, accountType, status, joinDate, image) VALUES ('$idno', '".$_POST["firstName"]."', '".$_POST["middleName"]."', '".$_POST["lastName"]."', '".$_POST["gender"]."', '$username', '$password', 'User', 'Pending', now(), '$image')";
				$result2 = mysqli_query($db, $sql2);

				if(mysqli_errno($db)) {
					if(mysqli_errno($db) == 1062) {
						echo ("<script language='javascript'>
								window.alert('The username is already taken!')
								window.location.href='index.php';
							</script>");
					}
				} else {
					echo ("<script language='javascript'>
							window.alert('You have successfully registered for a new account.')
							window.location.href='index.php';
							</script>");
				}
			}
		} else {
			echo ("<script language='javascript'>
					window.alert('An error occured while registering.')
					window.location.href='index.php';
				</script>");
		}
	}
?>