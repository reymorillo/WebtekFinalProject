<?php
	session_start();
	include('config.php');

	$sql = "SELECT *, CONCAT(u.fName, '&nbsp;', u.mName, '&nbsp;', u.lName) AS name FROM users u WHERE u.idno = '".$_SESSION["userID"]."'"; //change session['userID']
	$result = mysqli_query($db, $sql);

	$sql2 = "SELECT p.id, p.post, CONCAT(u.fName, '&nbsp;', u.lName) AS name, p.postedOn, p.visibility, p.image FROM posts p INNER JOIN users u ON p.idno = u.idno WHERE p.idno = '".$_SESSION["userID"]."' ORDER BY p.postedON DESC"; //change session['userID']
	$result2 = mysqli_query($db, $sql2);

	$sql3 ="SELECT c.id, c.idno, c.comment, c.datePublished, c.postID from comments c";
    $result3 = mysqli_query($db, $sql3);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<header>
		<input type="search" placeholder="Search for more friends">
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="requests.php">Requests</a></li>
				<li><a href="messages.php">Messages</a></li>
				<li><a href="profile.php">Profile</a></li> <!--insert php code to fetch user's name (optional)-->
				<li><a href="logout.php">Log out</a></li>
			</ul>
		</nav>
	</header>
    	
	<div class="modal fade" id="myModal" role="dialog">
	    <div class="modal-dialog">
    
	<div class="body">
		<div class="profile-header">
			<?php
				$row = $result->fetch_assoc();
				echo "<img id='myImg' src='data:image/jpeg;base64,".base64_encode($row["image"])."' height='200px' width='auto' />";
				echo "<h2>".$row['name']."</h2>";
				echo "<small>".$row['gender']."</small>";
				echo "<a href='editprofile.php'>Edit Profile</a>";
                
			?>
		</div>
		<div class="profile-body">
			<?php
				if($result2->num_rows > 0) {
					while($row = mysqli_fetch_array($result2)) {
						echo "<article class='post'>
							<h3>".$row['name']."</h3>
							<small>".$row['postedOn']."</small>
							<p>".$row['post']."</p>
							<form action='update.php' method='POST' enctype='multipart/form-data'>
                                <select name='visibility' onchange='this.form.submit()'>
                                    <option value='' name='option0'>".$row['visibility']."</option>
                                    <option value='Public' name='option1'>Public</option>
                                    <option value='Private' name='option2'>Private</option>
                                </select>
                                <input name='idno' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='".$_SESSION["userID"]."'/>
                                <input name='id' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='$row[id]'/>
                                <noscript><input type='submit' value='Submit'></noscript>
                            </form>";
                        echo "<form action='insert.php' method='POST' enctype='multipart/form-data'>
                                <textarea name='comments' placeholder='Leave Comments Here...' ></textarea>
                                <input name='postID' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='$row[id]'/>
                                <input type='submit' value='Submit'>
                              </form>";
                            if($result3->num_rows > 0 ){
	                            while($rows=mysqli_fetch_array($result3)){
	                            	echo "<hr>";
	                                echo "<div class='comments_content'>";
	                                echo "<small><a href='delete.php?id=" . $rows['id'] . "'> X</a></small>";
	                                echo"<p>".$row['name']."</p>";
	                                echo "<small>" . $rows['datePublished'] . "</small></br></br>";
	                                echo "<p>" . $rows['comment'] . "</p>";
	                                echo "</div>";
	                            }
	                        }
						echo "</article>";
					}
				}
			?>
		</div>
	</div>
	<footer>
		<div>
			<p>Copyright &copy; 2017 <a href="index.php">Community</a></p>
		</div>
	</footer>
</body>
</html>
