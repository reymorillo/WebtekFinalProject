<?php
	session_start();
	include('config.php');

	$searchValue = $_POST['searchValue'];

	$sql = "SELECT u.idno, CONCAT(u.fName, '&nbsp;', u.mName, '&nbsp;', u.lName) AS name, u.gender, u.image FROM users u WHERE u.idno != '".$_SESSION["userID"]."' AND u.status = 'Active' AND (u.fName LIKE '%$searchValue%' OR u.mName LIKE '%$searchValue%' OR u.lName LIKE '%$searchValue%') AND u.accountType = 'User' ORDER BY u.lName ASC";
	$result = mysqli_query($db, $sql);

	
	?>
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<style>
	.container {
		margin-top: 50px;
	}

	h3 {
		padding-left: 40px;
	}

	h2 {
		text-align: center;
	}

	small {
		padding-left: 20px;
	}

	form {
		padding-left: 20px;
	}

	img {
		border-radius: 50%;
	}
	</style>
</head>
<body>
	<header>
		<form method="POST" action="search.php">
			<input name="searchValue" type="search" placeholder="Search for more friends">
			<noscript><input type='submit' value='Submit'></noscript>
		</form>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="requests.php">Requests</a></li>
				<li><a href="messages.php">Messages</a></li>
				<li><a href="profile.php">Profile</a></li> <!--insert php code to fetch user's name (optional)-->
				<li><a href="logout.php">Log out</a></li>
			</ul>
		</nav>
	</header>
	
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="well well-sm">
			<h2>Result</h2>
				<table class="shadow">
					
					<tbody>
				 	
					<?php
						if($result->num_rows > 0) {
							while($row = mysqli_fetch_array($result)) {
										
										echo "<tr>";
										echo"<td><img id='myImg' src='data:image/jpeg;base64,".base64_encode($row['image'])."' height='50px' width='50px' /></td>";
										echo "<td><h3>".$row['name']."</h3></td>";
										echo "<td><small>".$row['gender']."</small></td>";
										echo "<td>
											<form action='addfriend.php' method='POST' enctype='multipart/form-data'>
		                                    	<input name='idno' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='$row[idno]'/>
		                                    	<input type='submit' value='Add as Friend' class='btn btn-success'>
		                                	</form>
											</td>";


										echo "<tr>";
										

							}
						}else{
							echo "No result found.";
						}
					?>	

					</tbody>
				</table>
					</div>
				</div> 
			</div>
		</div>
	
	
</body>
</html>