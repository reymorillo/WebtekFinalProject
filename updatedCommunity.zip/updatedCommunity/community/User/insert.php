<?php
	session_start();
	include('config.php');

$comment = $_POST['comment'];

$sql = "INSERT INTO comments (idno, comment, datePublished, postID) VALUES ('".$_SESSION["userID"]."','$comment', now(),'".$_POST["postID"]."')";
$result = mysqli_query($db, $sql);

echo ("<script language='javascript'>
            window.location.href='index.php';
        </script>");
?>