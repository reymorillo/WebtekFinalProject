$(function(){
    $(".chat").niceScroll();
})