<?php 
    include('config.php');
    session_start();



$sql ="SELECT DISTINCT
    (u.idno),
    CONCAT(u.fName,
            '&nbsp;',
            u.mName,
            '&nbsp;',
            u.lName) AS name,
    u.image, f.friendsWith, f.friendsSince, f.friendOf
FROM
    users u JOIN friends f ON  u.idno = f.friendsWith";

$result = mysqli_query($db, $sql);

echo("<script language='javascript'>
window.location.href='friendspage.php'; </script>");
?>


