<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style/style.css">
    <link rel="stylesheet" href="style/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="style/style1.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="bootstrap1.min.css"></head>
    <body>
        <body>
	<header>
		<form method="POST" action="search.php">
			<input name="searchValue" type="search" placeholder="Search for more friends">
			<noscript><input type='submit' value='Submit'></noscript>
		</form>
         
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="requests.php">Requests</a></li>
				<li><a href="messages.php">Messages</a></li>
				<li><a href="profile.php">Profile</a></li> <!--insert php code to fetch user's name (optional)-->
				<li><a href="logout.php">Log out</a></li>
			</ul>
		</nav>
	</header>
            
<?php
include('config.php');
session_start();
$sql = "SELECT CONCAT(u.fName, '&nbsp;', u.mName, '&nbsp;', u.lName) AS name, f.friendsWith, f.friendsSince, u.image from friends f JOIN users u ON f.friendsWith = u.idno";
$result = mysqli_query($db, $sql);
$sql1 =" SELECT CONCAT(u.fName, '&nbsp;', u.mName, '&nbsp;', u.lName) AS name from users u";
$result1 = mysqli_query($db, $sql1);
    if ($result->num_rows > 0) {
        while($row = mysqli_fetch_array($result)){
            echo"<tr>";
         echo"<td><img id='myImg' src='data:image/jpeg;base64,".base64_encode($row['image'])."' height='50px' width='auto' /></td>";
            echo "<h3>".$row['name']."</h3>";
            
            echo"<td>
            <form action='Friends.php' method='POST' enctype='multipart/form-data'>
            </form>
            <h3>".$row['friendsWith']."</h3>
           
           
        
            <p>".$row['friendsSince']."</p>";
           
            echo "</tr>";
        }
    }
   ?>