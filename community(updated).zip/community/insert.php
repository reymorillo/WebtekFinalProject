<?php
	session_start();
	include('config.php');

$name = $_REQUEST['name'];
$comments = $_REQUEST['comments'];



mysqli_query($con, "INSERT INTO comments(name, comments) VALUES('$name','$comments')");

$result = mysqli_query($con, "SELECT * FROM comments ORDER BY id ASC");
