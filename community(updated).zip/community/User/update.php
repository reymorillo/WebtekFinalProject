<?php
	session_start();
	include('config.php');

	$id = $_POST['id'];
	$accountID = $_POST['accountID'];
	$visibility = $_POST['visibility'];

	$sql = mysqli_query($db, "UPDATE posts SET visibility = '$visibility' WHERE accountID = '$accountID' AND id = '$id'");
	if($sql) {
		echo ("<script language='javascript'>
				window.location.href='profile.php';
			</script>");
	} else {
		echo ("<script language='javascript'>
				window.alert('An error occured while updating.')
				window.location.href='profile.php';
			</script>");
	}
?>