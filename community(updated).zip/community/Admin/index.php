<!--insert php code to connect to the database-->
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<header>
		<input type="search" placeholder="Search for more friends">
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="pending.php">Pending Accounts</a></li>
				<li><a href="suspended.php">Suspended Accounts</a></li>
				<li><a href="logout.php">Log out</a></li>
			</ul>
		</nav>
	</header>
	<div class="body">
		<div class="post">
			<form class="form-post" method = "POST">
				<textarea class="form-control" name="text" type="text" placeholder="Write what's on your mind."></textarea>
                <input name="addImg" id="addImg" type="file" accept="image/gif, image/jpeg, image/png">
				<select name="privacy">
					<option name="option1" value="Public">Public</option>
					<option name="option2" value="Private">Private</option>
				</select>
                <button class="btn btn-primary btn-block" type="submit">Post</button>
			</form>
		</div>
		<!-- insert php code here to fetch posts from friends -->
	</div>
	<footer>
		<div>
			<p>Copyright &copy; 2017 <a href="">Community</a></p>
		</div>
	</footer>
</body>
</html>