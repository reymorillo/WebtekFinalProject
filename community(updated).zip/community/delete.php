<?php
    session_start();
	include('config.php');

if(isset($_GET['id'])){
	$id = $_GET['id'];
mysqli_query($con,"DELETE FROM comments WHERE id='$id'");
header("location: index2.php");
}
mysqli_close($con);
?>