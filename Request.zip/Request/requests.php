<?php
	session_start();
	include('config.php');

	$sql = "SELECT r.requestFrom, r.requestTo, r.requestDate, CONCAT(u.fName, '&nbsp;', u.mName, '&nbsp;', u.lName) AS name, u.image, u.gender
	FROM requests r INNER JOIN users u ON r.requestFrom = u.idno WHERE r.requestTo = '".$_SESSION["userID"]."' AND r.status = 'Pending' ORDER BY r.requestDate DESC"; // change session['userid']
	$result = mysqli_query($db, $sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<header>
		<input type="search" placeholder="Search for more friends">
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="requests.php">Requests</a></li>
				<li><a href="messages.php">Messages</a></li>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="logout.php">Log out</a></li>
			</ul>
		</nav>
	</header>
	<div class="body">
		<div>
			<table>
				<tbody>
					<tr>
						<?php
							if($result->num_rows > 0) {
								while($row = mysqli_fetch_array($result)) {
									echo "<td><img id='myImg' src='data:image/jpeg;base64,".base64_encode($row["image"])."' height='75px' width='auto' /></td>";
									echo "<td>".$row['name']."</td>";
									echo "<td><small>".$row['gender']."</small></td>";
									echo "<td><small>".$row['requestDate']."</small></td>";
									echo "<td>
								<form action='accept.php' method='POST' enctype='multipart/form-data'>
		                       <input name='from' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='$row[requestFrom]'/>
                                            
		              <input name='Accept' type='submit' value='Accept Friend Request'>
                      <input name='Decline' type='submit' value='Decline'>
		                                </form>
									</td>";
								}
							}
						?>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<footer>
		<div>
			<p>Copyright &copy; 2017 <a href="index.php">Community</a></p>
		</div>
	</footer>
</body>
</html>