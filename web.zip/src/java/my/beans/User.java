
package my.beans;

/**
 *
 * @author Dirk
 */
public class User {
    private int idno;
    private String fName;
    private String mName;
    private String lName;
    private String gender;
    private String username;
    private String password;
    private String accountType;
    private String status;
    private String joinDate;
    
    public User(int idno, String fName, String mName, String lName, String gender, String username, String password, String accountType, String status) {
        this.idno = idno;
        this.fName = fName;
        this.mName = mName;
        this.lName = lName;
        this.gender = gender;
        this.username = username;
        this.password = password;
        this.accountType = accountType;
        this.status = status;
    }
    
    public int getIdno() {
        return idno;
    }

    public void setIdno(int idno) {
        this.idno = idno;
    }
    public String getgender() {
        return gender;
    }

    public void setgender(String gender) {
        this.gender = gender;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }
     public String getaccountType() {
        return fName;
    }

    public void setaccountType(String accountType) {
        this.accountType = accountType;
    }
     public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(String joinDate) {
        this.joinDate = joinDate;
    }
    
    
    
}
