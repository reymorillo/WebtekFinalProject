<?php
	session_start();
	include('config.php');

	$id = $_POST['id'];
	$idno = $_POST['idno'];
	$visibility = $_POST['visibility'];

	$sql = mysqli_query($db, "UPDATE posts SET visibility = '$visibility' WHERE idno = '$idno' AND id = '$id'");
	if($sql) {
		echo ("<script language='javascript'>
				window.location.href='profile.php';
			</script>");
	} else {
		echo ("<script language='javascript'>
				window.alert('An error occured while updating.')
				window.location.href='profile.php';
			</script>");
	}
?>