<?php
	session_start();
	include('config.php');
	if(isset($_POST['textarea'])) {
		if(!empty($_FILES['image']['error'] == 0)) {
	    	$image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
		} else {
			$image = null;
		}

	  	$sql = "INSERT INTO posts (idno, post, visibility, postedOn, image) VALUES ('".$_SESSION["userID"]."','".$_POST["textarea"]."','".$_POST["visibility"]."',now(),'$image')";
		$result = mysqli_query($db,$sql);

		$postID = mysqli_insert_id($db);

	

		

		
			echo ("<script language='javascript'>
						window.location.href='index.php';
					</script>");
		

	}
?>