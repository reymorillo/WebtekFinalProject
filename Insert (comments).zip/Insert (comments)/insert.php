<?php
	session_start();
	include('config.php');

$name = $_POST['name'];
$comments = $_POST['comments'];

mysqli_query($db, "INSERT INTO comment_box (name, comments, date_publish, post_id) VALUES('$name','$comments',now(),'".$_POST("postid")."')");

echo ("<script language='javascript'>
            window.location.href='index.php';
        </script>");
?>