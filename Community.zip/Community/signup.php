<?php
	include('config.php');
	session_start();

	if(isset($_POST['idno'])) {
		$idno = $_POST['idno'];
		$sql = "SELECT idno FROM users WHERE idno = '$idno'";
		$result = mysqli_query($db, $sql);
		$count = mysqli_num_rows($result);

		if($count == 0) {
			$username = $_POST['username'];
			$password = $_POST['password'];
			$username = stripslashes($username);
			$username = mysqli_real_escape_string($db, $username);
			$password = stripslashes($password);
			$password = mysqli_real_escape_string($db, $password);

			if(isset($username, $password)) {
				$sql2 = "INSERT INTO accounts (username, password, accountType, status) VALUES ('$username', '$password', 'User', 'Pending')";
				$result2 = mysqli_query($db, $sql2);

				if(mysqli_errno($db)) {
					if(mysqli_errno($db) == 1062) {
						echo ("<script language='javascript'>
								window.alert('The username is already taken!')
								window.location.href='index.php';
							</script>");
					}
				} else {
					if($result2) {
						$accountID = mysqli_insert_id($db);

						if(isset($_POST['firstName'], $_POST['middleName'], $_POST['lastName'], $_POST['age'], $_POST['birthday'], $_POST['gender'])) {
							if(!empty($_FILES['image']['error'] == 0)) {
								$image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
							} else {
								$image = addslashes(file_get_contents('avatar.jpg'));
							}

							$sql3 = "INSERT INTO users (accountID, idno, fName, mName, lName, age, birthdate, gender, photo, joinDate) VALUES ('$accountID', '".$_POST["idno"]."', '".$_POST["firstName"]."', '".$_POST["middleName"]."', '".$_POST["lastName"]."', '".$_POST["age"]."', '".$_POST["birthday"]."', '".$_POST["gender"]."','$image',now())";
							$result3 = mysqli_query($db, $sql3);

							echo ("<script language='javascript'>
									window.alert('You have successfully signed up! Please until your account is verified.')
									window.location.href='index.php';
									</script>");
						} else {
							echo ("<script language='javascript'>
									window.alert('There was an error while singing up.')
									window.location.href='index.php';
									</script>");
						}
					}
				}
			}
		} else {
			echo ("<script language='javascript'>
					window.alert('There is an account that already uses the same ID Number!')
					window.location.href='index.php';
				</script>");
		}
	} else {
		echo ("<script language='javascript'>
				window.alert('An error occured while registering.')
				window.location.href='index.php';
			</script>");
	}
?>