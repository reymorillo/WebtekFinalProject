<?php
	session_start();
	include('config.php');
	if(isset($_POST['textarea'])) {
		$sql = "INSERT INTO posts (accountID, post, postedOn, visibility) VALUES ('".$_SESSION["userID"]."','".$_POST["textarea"]."',now(),'".$_POST["visibility"]."')";
		$result = mysqli_query($db,$sql);

		echo ("<script language='javascript'>
					window.location.href='index.php';
				</script>");
	}
?>