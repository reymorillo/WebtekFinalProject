<?php
	session_start();
	include('config.php');

	$sql = "SELECT *, CONCAT(u.fName, '&nbsp;', u.mName, '&nbsp;', u.lName) AS name FROM users u WHERE u.accountID = '".$_SESSION["userID"]."'";
	$result = mysqli_query($db, $sql);

	$sql2 = "SELECT p.id, p.post, CONCAT(u.fName, '&nbsp;', u.lName) AS name, p.postedOn, p.visibility FROM posts p INNER JOIN users u ON p.accountID = u.accountID WHERE p.accountID = '".$_SESSION["userID"]."' ORDER BY p.postedON DESC";
	$result2 = mysqli_query($db, $sql2);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<header>
		<input type="search" placeholder="Search for more friends">
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="requests.php">Requests</a></li>
				<li><a href="messages.php">Messages</a></li>
				<li><a href="profile.php">Profile</a></li> <!--insert php code to fetch user's name (optional)-->
				<li><a href="logout.php">Log out</a></li>
			</ul>
		</nav>
	</header>
	<div class="body">
		<div class="profile-header">
			<?php
				$row = $result->fetch_assoc();
				echo "<img id='myImg' src='data:image/jpeg;base64,".base64_encode($row["photo"])."' height='200px' width='auto' />";
				echo "<h2>".$row['name']."</h2>";
				echo "<a href='editprofile.php'>Edit Profile</a>";
				echo "<ul>";
				echo "<li>".$row['gender']."</li>";
				echo "<li>".$row['age']."</li>";
				echo "<li>".$row['birthdate']."</li>";
				echo "</ul>";
			?>
		</div>
		<div class="profile-body">
			<?php
				if($result2->num_rows > 0) {
					while($row = mysqli_fetch_array($result2)) {
						echo "<article class='post'>
							<h3>".$row['name']."</h3>
							<small>".$row['postedOn']."</small>
							<p>".$row['post']."</p>
							<form action='update.php' method='POST' enctype='multipart/form-data'>
                                <select name='visibility' onchange='this.form.submit()'>
                                    <option value='' name='option0'>".$row['visibility']."</option>
                                    <option value='Public' name='option1'>Public</option>
                                    <option value='Private' name='option2'>Private</option>
                                </select>
                                <input name='accountID' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='".$_SESSION["userID"]."'/>
                                <input name='id' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='$row[id]'/>
                                <noscript><input type='submit' value='Submit'></noscript>
                            </form>
						</article>";
					}
				}
			?>
		</div>
	</div>
	<footer>
		<div>
			<p>Copyright &copy; 2017 <a href="">Community</a></p>
		</div>
	</footer>
</body>
</html>
</html>