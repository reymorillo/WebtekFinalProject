<!--insert php code to connect to the database-->
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<link rel="stylesheet" type="text/css" href="style/bootstrap/bootstrap.min.css">
	<script src="style/js/jquery.min.js"></script>
	<script src="style/js/bootstrap.min.js"></script>
</head>
<body>
	<header>
		<input type="search" placeholder="Search for more friends">
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="requests.php">Requests</a></li>
				<li><a href="messages.php">Messages</a></li>
				<li><a href="profile.php">Profile</a></li> <!--insert php code to fetch user's name (optional)-->
				<li><a href="logout.php">Log out</a></li>
			</ul>
		</nav>
	</header>
	<div class="body">
		<button data-target="#myModal" id="newMessage" data-toggle="modal">Write New Message</button>
	</div>
	<div class="modal fade" id="myModal" role="dialog">
	    <div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Write a new message...</h4>
				</div>
				<div class="modal-body">
					<form method="POST" action="send.php" enctype="multipart/form-data">
						<div>
							<input type="text" name="recepient" placeholder="Recepient" required>
							<!--insert php statement here-->
						</div>
						<div>
							<textarea class="form-control" name="textarea" type="text"></textarea>
						</div>
						<input name="image" id="image" type="file" multiple accept="image/gif, image/jpeg, image/png">
						<input name="send" id="send" class="btn btn-default submit-button" type="submit" value="Send">
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
	    </div>
	</div>
	<footer>
		<div>
			<p>Copyright &copy; 2017 <a href="">Community</a></p>
		</div>
	</footer>
</body>
</html>
