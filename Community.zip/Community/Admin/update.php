<?php
	include('config.php');

	$id = $_POST['accountID'];

	$sql = mysqli_query($db, "UPDATE accounts SET status = 'Active' WHERE accountID = '$id'");
	$sql2 = mysqli_query($db, "UPDATE users SET joinDate = now() WHERE accountID = '$id'"); 

	if($sql && $sql2) {
		echo ("<script language='javascript'>
				window.alert('The user account been activated.')
				window.location.href='pending.php';
			</script>");
	} else {
		echo ("<script language='javascript'>
				window.alert('An error occured while updating the account.')
				window.location.href='pending.php';
			</script>");
	}
?>