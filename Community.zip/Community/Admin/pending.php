<?php
	include('config.php');
	session_start();

	$sql = "SELECT u.idno, u.accountID, CONCAT(u.fName, '&nbsp;', u.lName) AS name FROM users u INNER JOIN accounts a ON u.accountID = a.accountID WHERE status = 'Pending' ORDER BY u.joinDate";
	$result = mysqli_query($db, $sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<header>
		<input type="search" placeholder="Search for more friends">
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="pending.php">Pending Accounts</a></li>
				<li><a href="suspended.php">Suspended Accounts</a></li>
				<li><a href="logout.php">Log out</a></li>
			</ul>
		</nav>
	</header>
	<div class="body">
		<div class="table-responsive">
			<table class="table table-hover table-bordered">
				<thead>
					<tr>
						<th>ID Number</th>
						<th>Name</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<?php
						if($result->num_rows > 0) {
							while($row = mysqli_fetch_array($result)) {
								echo "<tr>";
								echo "<td>".$row['idno']."</td>";
								echo "<td>".$row['name']."</td>";
								echo "<td>
										<form action='update.php' method='POST' enctype='multipart/form-data'>
		                                    <input name='accountID' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='$row[accountID]'/>
		                                    <input type='submit' value='Allow'>
		                                </form>
									</td>";
								echo "</tr>";
							}
						}
					?>
				</tbody>
			</table>
		</div>
	</div>
	<footer>
		<div>
			<p>Copyright &copy; 2017 <a href="">Community</a></p>
		</div>
	</footer>
</body>
</html>