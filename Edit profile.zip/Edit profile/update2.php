<?php
    include('config.php');
    session_start();

$fName =$_POST['fName'];
$mName = $_POST['mName'];
$lName =$_POST['lName'];
$username = $_POST['username'];
$password = $_POST['password'];

$sql = mysqli_query($db, "UPDATE users SET fName = '$fName', mName = '$mName', lName = '$lName' WHERE accountID = '".$_SESSION["userID"]."'");
                    
if($sql)
	{
		$text = 'Details of'. ' ' .$fName. ' ' .'has been updated';
		echo ("<SCRIPT LANGUAGE='JavaScript'>
                            window.alert('Successfully Updated')
                            window.location.href='profile.php';
                            </SCRIPT>");
	}
	else{
		echo ("<SCRIPT LANGUAGE='JavaScript'>
                            window.alert('Not Updated!')
                            window.location.href='profile.php';
                            </SCRIPT>");
	}


?>



