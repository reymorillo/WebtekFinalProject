<?php
include('config.php');
session_start();


$sql = "SELECT * from users u JOIN accounts a on u.accountID = a.accountID where a.accountID ='".$_SESSION["userID"]."'";

$result = mysqli_query($db, $sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()){
            echo" <form name='editprofile' action='update2.php' method='POST'>
            <div class='form-group'>
                <div>
                    <input class='form-control' type='text' name='fName' value='$row[fName]'>
                </div>
                <small>First Name</small>
            </div>
            </div>
           
              <div class='form-group'>
                        <div>
                            <input class='form-control' type='text' name='mName' value='$row[mName]'>
                        </div>
                        <div>
                            <small>Middle Name</small>
                        </div>
                    </div>
            <div class='form-group'>
                    <div>
                        <input class='form-control' type='text' name='lName' value='$row[lName]'>
                        </div>
                        <div>
                            <small>Last Name</small>
                        </div>
                    </div>
                <div class='form-group'>
                    <div>
                        <input class='form-control' type='text' name='username' value='$row[username]'>
                        </div>
                        <div>
                            <small>Username</small>
                        </div>
                    </div>
                     </div>
                <div class='form-group'>
                    <div>
                        <input class='form-control' type='text' name='password' value='$row[password]'>
                        </div>
                        <div>
                            <small>Password</small>
                        </div>
                  
                     </div>
                     <div class='form-group'>
                        <button class='btn btn-default btn-block submit-button' type='Submit' value='Submit' id='submit'>Save Changes</button>
                    </div>

                </form>
                ";
                    
        }
    }
?>