<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style/style.css">
    <link rel="stylesheet" href="style/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="style/style1.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="bootstrap1.min.css"></head>
    <body>
        <body>
	<header>
		<form method="POST" action="search.php">
			<input name="searchValue" type="search" placeholder="Search for more friends">
			<noscript><input type='submit' value='Submit'></noscript>
		</form>
         
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="requests.php">Requests</a></li>
				<li><a href="messages.php">Messages</a></li>
				<li><a href="profile.php">Profile</a></li> <!--insert php code to fetch user's name (optional)-->
				<li><a href="logout.php">Log out</a></li>
			</ul>
		</nav>
	</header>
  
<?php
include('config.php');
session_start();


$sql = "SELECT * from users u WHERE u.idno ='".$_SESSION["userID"]."'";

$result = mysqli_query($db, $sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()){
            echo" <div class='mainbody container-fluid'>
            
            <div class='col-lg-9 col-md-9 col-sm-12 col-xs-12'>
            <div class='panel panel-default'>
                <div class='panel-body'>
                    <h1 class='panel-title pull-left' style='font-size:30px;'>My basic profile</h1>
                </div>
                  <div class='panel panel-default'>
                <div class='panel-body'>
                    <h3 class='panel-title pull-left'>Your Name</h3>
                    <br><br>
        
            <form class='editprofile' action='update2.php' method='POST' enctype='multipart/form-data'>
                    <div class='form-group'>
                        <div>
                            <small>First Name</small>
                        </div>
                        <div>
                            <input class='form-control' type='text' name='fName' value='$row[fName]'>
                        </div>
                        
                    </div>
                    <div class='form-group'>
                     <div>
                            <small>Middle Name</small>
                        </div>
                        <div>
                            <input class='form-control' type='text' name='mName' value='$row[mName]'>
                        </div>
                       
                    </div>
                    <div class='form-group'>
                     <div>
                            <small>Last Name</small>
                        </div>
                        <div>
                            <input class='form-control' type='text' name='lName' value='$row[lName]'>
                        </div>
                       
                    </div>
                    <div class='form-group'>
                    <div>
                            <small>Username</small>
                        </div>
                        <div>
                            <input class='form-control' type='text' name='username' value='$row[username]'>
                        </div>
                        
                    </div>
                    <div class='form-group'>
                    <div>
                            <small>Password</small>
                        </div>
                        <div>
                            <input class='form-control' type='text' name='password' value='$row[password]'>
                        </div>
                        
                  
                    </div>
                      <div class='panel panel-default'>
                <div class='panel-body'>
                    <h3 class='panel-title pull-left'>Your photo</h3>
                    <br><br>
                    <div align='center'>
                        <div class='col-lg-12 col-md-12'>
                    <div class='form-group'>
                        <div>
                            <img id='myImg' src='data:image/jpeg;base64,".base64_encode($row["image"])."' height='100px' width='auto' />
                        </div>
                        <div>
                           	<small>Upload Profile Photo:</small>
                            <input name='image' id='image' value='' type='file' multiple accept='image/gif, image/jpeg, image/png'>
        			    </div>
                    </div>
                    <div class='form-group'>
                        <div>
                            <button class='btn btn-default btn-block submit-button' type='Submit' value='Submit' id='submit'>Save Changes</button>
                        </div>
                    </div>
                </form>";
                    
        }
    }
?>
</html>