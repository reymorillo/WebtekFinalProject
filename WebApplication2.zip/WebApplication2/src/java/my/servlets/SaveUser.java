package my.servlets;

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet(name = "SaveUser", urlPatterns = {"/SaveUser"})
@MultipartConfig
public class SaveUser extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int idnum = Integer.parseInt((request.getParameter("idnum")));
        String fName = request.getParameter("fName");
        String mName = request.getParameter("mName");
        String lName = request.getParameter("lName");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");
        Part image = request.getPart("image");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/script", "root", null);
            
            String sql = "INSERT INTO users(idnum, fName, mName, lName, username, password, gender, image) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement ps = connection.prepareStatement(sql);
            
            ps.setInt(1, idnum);
            ps.setString(2, fName);
            ps.setString(3, mName);
            ps.setString(4, lName);
            ps.setString(5, username);
            ps.setString(6, password);
            ps.setString(7, gender);              
            ps.setBlob(8, image.getInputStream());
           
            int rowsAffected = ps.executeUpdate();
            
            String path = this.getServletContext().getRealPath("/productimages");
            String filename = path + "/" + idnum + ".jpg";
            image.write(filename);
            
            if (rowsAffected == 1) {
                response.sendRedirect("success.html");
                return;
            } 
        } catch (Exception ex) {
            Logger.getLogger(SaveUser.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        RequestDispatcher rd = request.getRequestDispatcher("failed.html");
        rd.forward(request, response);
    }
}
