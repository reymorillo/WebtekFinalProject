<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<title>Prelim Schedule</title>
</head>
<body>
	 <link rel="stylesheet" type="text/css" href="style2.css">
	<div id="fullscreen_bg" class="fullscreen_bg"/>
 <form class="form-signin">
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-default">
        <div class="panel panel-primary">
        
            <h3 class="text-center">
                        Schedule</h3>
        
        <div class="panel-body">    
 
 
 <table class="table table-striped table-condensed">
              <tbody>
                <tr>
                    
                    <td>Prelims</td>
                    <td>Miderms</td>
                    <td>Finals</td> 
                 
                    </td>                                       
                </tr>
                <tr>
                    
                    <td>7:00-8:00</td>
                    <td>-</td>
                    <td>-</td>
              
                </tr>
                <tr>
                    
                    <td>10:00-11:00</td>
                    <td>-</td>
                    <td>-</td>

                </tr>
                <tr>
                
                    <td>11:00-12:00</td>
                    <td>-</td>
                    <td>-</td>
      
                </tr>
                <tr>
                    
                    <td>2:00-3:00</td>
                    <td>-</td>
                    <td>-</td>
                  
                </tr>
        
              </tbody>
              
  </div>
       </div>
        </div>
    </div>
</div>
</form>
              
            </table>

</body>
</html>