<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Homepage</title>
     <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <link rel="stylesheet" type="text/css" href="style1.css">
  <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>

<nav class="navbar navbar-default" style="background-color:#3366ff;width:80%;margin:auto;margin-top:50px;">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="homepage.php" style="color:white;font-family:raleway;">SLU</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div style="font-family:Oswald;" class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav" style="color:white;">
        <li><a href="profile.php" style="color:white;"><i class="fa fa-profile"></i>  Profile</a></li>
        <li><a href="inbox.php" style="color:white;"><i class="fa fa-messenger"></i>  Messenger</a></li>
        </ul>
       <ul class="nav navbar-nav navbar-right"> 
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			        <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>


<div class="home">
    
   <h1>Welcome</h1>
   <p><i class="fa fa-home"></i></i></p>
   <p>Welcome on our website</p>
   
   
   
   
<div class="container">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
    
      <!-- Wrapper for slides -->
      <div class="carousel-inner">
      
        <div class="item active">
        <div class = "images">
          <img src="http://www.slu.edu.ph/images/stories/slideshow/caldonamunoz0617.jpg">
        </div>
           <div class="carousel-caption">
            <h4><a href="http://www.slu.edu.ph/images/stories/som/3rdbatchapril2717.pdf">3rd Batch of Qualified Incoming Freshmen for School of Medicine</a></h4>
          </div>
        </div><!-- End Item -->
 
         <div class="item">
           <div class = "images">
          <img src="http://www.slu.edu.ph/images/stories/slideshow/lhs050917.jpg">
          </div>
           <div class="carousel-caption">
          </div>
        </div><!-- End Item -->
        
        <div class="item">
          <div class = "images">
          <img src="http://www.slu.edu.ph/images/stories/slideshow/magnificusslide030617.jpg">
          </div>
           <div class="carousel-caption">
            <h4><a href="http://www.slu.edu.ph/images/stories/sol/magnificusjuris030617.jpg">Magnificus Juris</a></h4>
          </div>
        </div><!-- End Item -->
        
        <div class="item">
          <div class = "images">
          <img src="http://www.slu.edu.ph/images/stories/slideshow/fulbrigh2t.jpg">
          </div>
           <div class="carousel-caption">
            <h4><a href="http://aseanop.com/fulbright-student-fellowships-2018-2019-opened-application/">Scholarships</a></h4>
          </div>
        </div><!-- End Item -->

        <div class="item">
          <div class = "images">
          <img src="http://www.slu.edu.ph/images/stories/slideshow/sol053117.jpg">
          </div>
           <div class="carousel-caption">
          </div>
        </div><!-- End Item -->
                
      </div><!-- End Carousel Inner -->


    <ul class="list-group col-sm-4">
      <li data-target="#myCarousel" data-slide-to="0" class="list-group-item active"><h4>School of Medicine</h4></li>
      <li data-target="#myCarousel" data-slide-to="1" class="list-group-item active"><h4>SLU Laboratory Highschool</h4></li>
      <li data-target="#myCarousel" data-slide-to="2" class="list-group-item"><h4>Magnificus Juris</h4></li>
      <li data-target="#myCarousel" data-slide-to="3" class="list-group-item"><h4>Scholarships</h4></li>
      <li data-target="#myCarousel" data-slide-to="4" class="list-group-item"><h4>School of Law</h4></li>
    </ul>

      <!-- Controls -->
      <div class="carousel-controls">
          <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
          </a>
          <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
          </a>
      </div>

    </div><!-- End Carousel -->
</div>   
    
<br/><br/><br/>

<div class="row" style="padding-right:75px;padding-left:75px;">
<div class="col-md-4">
<h1><span class="fa-stack fa-lg">
  <i class="fa fa-circle fa-stack-2x"></i>
  <i class="fa fa-plane fa-stack-1x fa-inverse"></i>
</span></h1>
<br/>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ultrices, odio sit amet mattis tristique.</p>
</div> 

<div class="col-md-4">
<h1><span class="fa-stack fa-lg">
  <i class="fa fa-circle fa-stack-2x"></i>
  <i class="fa fa-fighter-jet fa-stack-1x fa-inverse"></i>
</span></h1>
<br/>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ultrices, odio sit amet mattis tristique.</p>
</div> 

<div class="col-md-4">
<h1><span class="fa-stack fa-lg">
  <i class="fa fa-circle fa-stack-2x"></i>
  <i class="fa fa-rocket fa-stack-1x fa-inverse"></i>
</span></h1>
<br/>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ultrices, odio sit amet mattis tristique.</p>
</div> 
</div>
<br/><br/><p></p><i class="fa fa-file-text-o fa-3x"></i></p></br></br>    
<div class="row" style="padding-right:50px;padding-left:50px;">
<div class="col-md-6">
<h1>About me</h1>
<br/>
<p>Caput tempore imperii cuius templum cupiebat postulatus tempore fatidicum vetitis an quo fatidicum pulsatae vetitis portenderetur an cunctum ut cum ut templum pileo operiebat maiestatis Serenianus incertum absolvi operiebat cupiebat quaeritatum Phoenice imperium artibus firmum ut caput templum expresse artibus pileo et firmum misisse cum caput quaeritatum incertum caput quo aperte maiestatis familiarem tempore qua imperii ignavia vetitis expresse portenderetur ex an ad operiebat populatam convictus incertum Celsen in ac incertum ex lege caput absolvi cum fatidicum quaeritatum incertum operiebat fatidicum reus qua operiebat quo ut caput Celsen cum templum firmum expresse iure quaeritatum pileo duce cupiebat incantato incertum ac.</p>    
</div>     
<div class="col-md-6">

<h1>My Skills</h1>
<br/>
<p style="text-align:left;">CSS</p>
<div class="progress progress-striped">
  <div class="progress-bar progress-bar-info" style="width: 20%"></div>
</div>
<p style="text-align:left;">HTML</p>
<div class="progress progress-striped">
  <div class="progress-bar progress-bar-success" style="width: 40%"></div>
</div>
<p style="text-align:left;">PHP</p>
<div class="progress progress-striped">
  <div class="progress-bar progress-bar-warning" style="width: 60%"></div>
</div>
<p style="text-align:left;">Javascript</p>
<div class="progress progress-striped">
  <div class="progress-bar progress-bar-danger" style="width: 80%"></div>
</div>    
</div>      
</div>    
    
<br/><br/><p></p><i class="fa fa-bars fa-3x"></i></p><br/><br/>
<h2>MENU</h2>
<center>
<div class="row db-padding-btm db-attached" style="width:90%;margin-auto;">
            <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                <div class="db-wrapper">
                    <div class="db-pricing-eleven db-bk-color-one">
                        <div class="price">
                            <sup>
                              EXAM
                            </sup>
                        </div>
                        <div class="type">
                            SCHEDULE
                        </div>
                        <ul>

                            <li><i class="glyphicon glyphicon-triangle-right"></i>Prelim </li>
                            <li><i class="glyphicon glyphicon-triangle-right"></i>Midterms</li>
                            <li><i class="glyphicon glyphicon-triangle-right"></i>Finals</li>
                        </ul>
                        <div class="pricing-footer">

                            <a href="schedule.php" class="btn db-button-color-square btn-lg">See more</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                 <div class="db-wrapper">
                <div class="db-pricing-eleven db-bk-color-two popular">
                    <div class="price">
                        <sup>SLU</sup>
                    </div>
                    <div class="type">
                        Portal
                    </div>
                    <ul>

                        <li><i class="glyphicon glyphicon-triangle-right"></i>Grades </li>
                        <li><i class="glyphicon glyphicon-triangle-right"></i>Schedules </li>
                        <li><i class="glyphicon glyphicon-triangle-right"></i>Account</li>
                    </ul>
                    <div class="pricing-footer">

                        <a href="https://i.slu.edu.ph/" class="btn db-button-color-square btn-lg">Portal</a>
                    </div>
                </div>
                     </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                 <div class="db-wrapper">
                <div class="db-pricing-eleven db-bk-color-three">
                    <div class="price">
                        <sup>SLU</sup>
                    </div>
                    <div class="type">
                        MAIN WEBSITE
                    </div>
                    <ul>

                        <li><i class="glyphicon glyphicon-triangle-right"></i>About SLU</li>
                        <li><i class="glyphicon glyphicon-triangle-right"></i>News</li>
                        <li><i class="glyphicon glyphicon-triangle-right"></i>Academics</li>
                    </ul>
                    <div class="pricing-footer">

                        <a href="http://www.slu.edu.ph" class="btn db-button-color-square btn-lg">SLU</a>
                    </div>
                </div>
                     </div>
            </div>

        </div>
</center>


<br/><br/><p></p><i class="fa fa-picture-o fa-3x"></i></p><br/><br/>
<h2>Pictures</h2>
<br/><br/>
    <img src="https://media.giphy.com/media/LMPfaJXyY7cKA/giphy.gif">  
    
</div>


<br/><br/><br/><br/>


<div class="panel panel-default" style="background-color:rgba(51, 102, 255,0.7);width:80%;margin-bottom:50px;color:white;margin-right:auto;margin-left:auto;">
<div class="panel-body">
<div class="row">
<div class="col-md-4">
<h1 style="float:left;">Enterprise  </h1>   <p style="margin-left:10px;">Anazarbus Iovis Iovis quidam repentina Africae perspicabilis Danaes referens a referens opulentus mors Mopsuestia sospitales amni profectus a et referensAnazarbus Iovis Iovis quidam repentina Africae perspicabilis Danaes referens a referens opulentus mors Mopsuestia sospitales amni profectus a et referensAnazarbus Iovis Iovis quidam repentina Africae perspicabilis Danaes referens a referens opulentus mors Mopsuestia sospitales amni profectus a et referens.</p>

</div>  
<div class="col-md-4">
<ul class="list-group" style="color:black;">
  <li class="list-group-item"><a href="#">Cras justo odio</a></li>
  <li class="list-group-item"><a href="#">Dapibus ac facilisis in</a></li>
  <li class="list-group-item"><a href="#">Morbi leo risus</a></li>
  <li class="list-group-item"><a href="#">Porta ac consectetur ac</a></li>
  <li class="list-group-item"><a href="#">Vestibulum at eros</a></li>
</ul>
</div>    
<div class="col-md-4">
<div style="margin:auto;">
Coded with :
<h1><i class="fa fa-css3"></i> & <i class="fa fa-html5"></i></h1>
</div>

</div>    
</div>
</div>
<div class="panel-footer" style="background-color:rgb(51, 102, 255);border:0px black solid;color:white;"><i class="fa fa-rocket"></i> Designed by <a href="http://amji-dev.raidghost.com/" style="text-decoration:underlines;color:white;" target="_blank">Amjido</a></div>
</div>
 <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <script type="text/javascript">
       $(document).ready(function(){
    
    var clickEvent = false;
  $('#myCarousel').carousel({
    interval:   4000  
  }).on('click', '.list-group li', function() {
      clickEvent = true;
      $('.list-group li').removeClass('active');
      $(this).addClass('active');   
  }).on('slid.bs.carousel', function(e) {
    if(!clickEvent) {
      var count = $('.list-group').children().length -1;
      var current = $('.list-group li.active');
      current.removeClass('active').next().addClass('active');
      var id = parseInt(current.data('slide-to'));
      if(count == id) {
        $('.list-group li').first().addClass('active'); 
      }
    }
    clickEvent = false;
  });
})

$(window).load(function() {
    var boxheight = $('#myCarousel .carousel-inner').innerHeight();
    var itemlength = $('#myCarousel .item').length;
    var triggerheight = Math.round(boxheight/itemlength+1);
  $('#myCarousel .list-group-item').outerHeight(triggerheight);
});
</script>
</body>
</html>
<?php ob_end_flush(); ?>