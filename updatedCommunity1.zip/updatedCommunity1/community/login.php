<?php
	include("config.php");
	session_start();
	if($_SERVER["REQUEST_METHOD"] == "POST") {
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);
		$sql = "SELECT * FROM users WHERE username = '$username'";
		$result = mysqli_query($db, $sql);
		$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
		$count = mysqli_num_rows($result);

		if($password == $row['password']) {
			if($count == 1 && $row['accountType'] == 'User' && $row['status'] == 'Active') {
				$_SESSION['username'] = $username;
				$_SESSION['userID'] = $row['idno'];
				$_SESSION['accountType'] = 'User';
				$_SESSION['loggedin'] = true;
				header("Location: User/index.php");
			} else if($count == 1 && $row['accountType'] == 'Admin' && $row['status'] == 'Active') {
				$_SESSION['username'] = $username;
				$_SESSION['userID'] = $row['idno'];
				$_SESSION['accountType'] = 'Admin';
				$_SESSION['loggedin'] = true;
				header("Location: Admin/index.php");
			} else {
				$message = "You have entered an invalid username or password.";
				echo "<script type='text/javascript'>alert('$message');</script>";
			}
		} else {
			$message = "You have entered an invalid username or password.";
			echo "<script type='text/javascript'>alert('$message');</script>";
		}
	}
?>