<?php
	session_start();
	include('config.php');

	$sql = "SELECT r.requestFrom, r.requestTo, r.requestDate, CONCAT(u.fName, '&nbsp;', u.mName, '&nbsp;', u.lName) AS name, u.image, u.gender
	FROM requests r INNER JOIN users u ON r.requestFrom = u.idno WHERE r.requestTo = '".$_SESSION["userID"]."' AND r.status = 'Pending' ORDER BY r.requestDate DESC"; // change session['userid']
	$result = mysqli_query($db, $sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<link rel="stylesheet" type="text/css" href="style/bootstrap/bootstrap.min.css">
	<sript src="style/js/bootstrap.min.js"></script>
	<script src="style/js/bootstrap/jQuery.min.js"></script>

</head>
<body>
	<header>
		<div class="container">
		<nav class="navbar navbar-default" role="navigation">
		<div class="container-fluid navbar-border">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav">
				<li class="dropdown">
					<form class="navbar-form" role="search" method = "POST" action = "search.php">
					<div class="input-group">
						<input type="text" class="form-control" placeholder="Enter friends name..." name="searchValue" minlength="">
					</div>
					</form>    
				</li>
				<li><a href="index.php"><i class="fa fa-building"></i> Home</a></li>
				<li><a href="requests.php"><i class="fa fa-building"></i> Requests</a></li>
				<li><a href="profile.php"><i class="fa fa-building"></i><?php echo "".$_SESSION['userID']."" ?></a></li>
			</ul>
			
			 <ul class="nav navbar-nav navbar-right">
				<li><a href="logout.php"><i class= "fa fa-building"></i>Sign out </a></li>
				</li>
			</ul>
			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
		</nav>
		</div>
	</header>
	<div class="body">
		<div>
			<table>
				<tbody>
					<tr>
						<?php
							if($result->num_rows > 0) {
								while($row = mysqli_fetch_array($result)) {
									echo "<td><img id='myImg' src='data:image/jpeg;base64,".base64_encode($row["image"])."' height='75px' width='auto' /></td>";
									echo "<td>".$row['name']."</td>";
									echo "<td><small>".$row['gender']."</small></td>";
									echo "<td><small>".$row['requestDate']."</small></td>";
									echo "<td>
								<form action='accept.php' method='POST' enctype='multipart/form-data'>
		                       <input name='from' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='$row[requestFrom]'/>
                                            
		              <input name='Accept' type='submit' value='Accept Friend Request'>
                      <input name='Decline' type='submit' value='Decline'>
		                                </form>
									</td>";
								}
							}
						?>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<footer>
		<div>
			<p>Copyright &copy; 2017 <a href="index.php">Community</a></p>
		</div>
	</footer>
</body>
</html>