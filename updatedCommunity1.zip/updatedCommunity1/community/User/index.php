<?php
	session_start();
	include('config.php');

	$sql = "SELECT p.id, u.idno, CONCAT(u.fName, '&nbsp;', u.lName) as name, p.post, p.postedOn, p.image AS photo,u.image
			FROM posts p INNER JOIN users u ON p.idno = u.idno
			WHERE p.visibility = 'Public'ORDER BY p.postedOn DESC";
	$result = mysqli_query($db, $sql);
    
    $sql2 ="SELECT c.id, CONCAT(u.fName, '&nbsp;', u.lName) AS name, c.comment, c.datePublished, c.postID, u.image FROM comments c INNER JOIN users u ON c.user = u.idno";
    $result2 = mysqli_query($db, $sql2);
    $sql3="SELECT u.image from users";
    $result3 = mysqli_query($db, $sql3);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<link rel="stylesheet" type="text/css" href="style/bootstrap/bootstrap.min.css">
	<sript src="style/js/bootstrap.min.js"></script>
	<script src="style/js/bootstrap/jQuery.min.js"></script>

</head>
<body>
	<header>
		<div class="container">
		<nav class="navbar navbar-default" role="navigation">
		<div class="container-fluid navbar-border">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav">
				<li class="dropdown">
					<form class="navbar-form" role="search" method = "POST" action = "search.php">
					<div class="input-group">
						<input type="text" class="form-control" placeholder="Enter friends name..." name="searchValue" minlength="">
					</div>
					</form>    
				</li>
				<li><a href="index.php"><i class="fa fa-building"></i> Home</a></li>
				<li><a href="requests.php"><i class="fa fa-building"></i> Requests</a></li>
				<li><a href="profile.php"><i class="fa fa-building"></i><?php echo "".$_SESSION['userID']."" ?></a></li>
			</ul>
			
			 <ul class="nav navbar-nav navbar-right">
				<li><a href="logout.php"><i class= "fa fa-building"></i>Sign out </a></li>
				</li>
			</ul>
			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
		</nav>
		</div>
	</header>
	<div class="body">
		<div class="post">
			<form class="form-post" method = "POST" action="post.php" enctype="multipart/form-data">
				<textarea class="form-control" name="textarea" type="text" placeholder="Write what's on your mind."></textarea>
                <input name="image" id="image" type="file" multiple accept="image/gif, image/jpeg, image/png">
				<select name="visibility">
					<option name="option1" value="Public">Public</option>
					<option name="option2" value="Private">Private</option>
				</select>
                <button type="submit">Post</button>
			</form>
		</div>
  
        
		<?php
			if($result->num_rows > 0) {
				while($row = mysqli_fetch_array($result)) {
                   
					echo "<article class='post'>
                            <img id='myImg' src='data:image/jpeg;base64,".base64_encode($row["image"])."' height='50px' width='auto' />

							<h3>".$row['name']."</h3>
							<small>".$row['postedOn']."</small>";

                     if($row['image']!=null){
								echo "<img id='my>>>Img' src='data:image/jpeg;base64,".base64_encode($row["photo"])."' height='200px' width='auto' />";
							}
                        echo "<p>".$row['post']."</p>
                        <form action='insert.php' method='POST' enctype='multipart/form-data'>
	                <textarea name='comment' placeholder='Leave Comments Here...' ></textarea>
	                <input name='postID' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='$row[id]'/>
	                                <input type='submit' value='Submit'>
                                </form>";
                             
                            if($result2->num_rows > 0 ){
	                            while($rows=mysqli_fetch_array($result2)) {
	                            	if($rows['postID'] == $row['id']){
	                            		echo "<hr>";   
		                                echo "<div class='comments_content'>";
		                                echo "<small><a href='delete.php?id=".$rows['id']."'> X</a></small>";
                                        
                                        echo "<img id='myImg' src='data:image/jpeg;base64,".base64_encode($rows["image"])."' height='50px' width='auto' />";
                                        
		                                echo"<p>".$row['name']."</p>";
		                                echo "<small>".$rows['datePublished']."</small></br></br>";
		                                echo "<p>".$rows['comment']."</p>";
		                                echo "</div>";
	                            	}
	                            }
                            }
						echo"</article>"; 
				}
			}
		?>
	</div>
	<footer>
		<div>
			<p>Copyright &copy; 2017 <a href="index.php">Community</a></p>
		</div>
	</footer>
</body>
</html>