<?php
	session_start();
	include('config.php');

	$searchValue = $_POST['searchValue'];

	$sql = "SELECT u.idno, CONCAT(u.fName, '&nbsp;', u.mName, '&nbsp;', u.lName) AS name, u.gender, u.image FROM users u WHERE u.idno != '".$_SESSION["userID"]."' AND u.status = 'Active' AND (u.fName LIKE '%$searchValue%' OR u.mName LIKE '%$searchValue%' OR u.lName LIKE '%$searchValue%') AND u.accountType = 'User' ORDER BY u.lName ASC";
	$result = mysqli_query($db, $sql);

	
	?>
<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<link rel="stylesheet" type="text/css" href="style/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<sript src="style/js/bootstrap.min.js"></script>
	<script src="style/js/bootstrap/jQuery.min.js"></script>

	<style>
	h3 {
		padding-left: 40px;
	}

	h2 {
		text-align: center;
	}

	small {
		padding-left: 20px;
	}

	form {
		padding-left: 20px;
	}

	img {
		border-radius: 50%;
	}
	</style>
</head>
<body>
		<div class="container">
		<nav class="navbar navbar-default" role="navigation">
		<div class="container-fluid navbar-border">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
			</button>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav">
				<li class="dropdown">
					<form class="navbar-form" role="search" method = "POST" action = "search.php">
					<div class="input-group">
						<input type="text" class="form-control" placeholder="Enter friends name..." name="searchValue" minlength="">
					</div>
					</form>    
				</li>
				<li><a href="index.php"><i class="fa fa-building"></i> Home</a></li>
				<li><a href="requests.php"><i class="fa fa-building"></i> Requests</a></li>
				<li><a href="profile.php"><i class="fa fa-building"></i><?php echo "".$_SESSION['userID']."" ?></a></li>
			</ul>
			
			 <ul class="nav navbar-nav navbar-right">
				<li><a href="logout.php"><i class= "fa fa-building"></i>Sign out </a></li>
				</li>
			</ul>
			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
		</nav>
		</div>
	
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="well well-sm">
			<h2>Result</h2>
				<table class="shadow">
					
					<tbody>
				 	
					<?php
						if($result->num_rows > 0) {
							while($row = mysqli_fetch_array($result)) {
										
										echo "<tr>";
										echo"<td><img id='myImg' src='data:image/jpeg;base64,".base64_encode($row['image'])."' height='50px' width='50px' /></td>";
										echo "<td><h3>".$row['name']."</h3></td>";
										echo "<td><small>".$row['gender']."</small></td>";
										echo "<td>
											<form action='addfriend.php' method='POST' enctype='multipart/form-data'>
		                                    	<input name='idno' type='hidden' oncopy='return false' onpaste='return false' onkeyup='javascript:this.value=this.value.replace(/[<,>]/g,'');' value='$row[idno]'/>
		                                    	<input type='submit' value='Add as Friend' class='btn btn-success'>
		                                	</form>
											</td>";


										echo "<tr>";
										

							}
						}else{
							echo "No result found.";
						}
					?>	

					</tbody>
				</table>
					</div>
				</div> 
			</div>
		</div>
	
	
</body>
</html>